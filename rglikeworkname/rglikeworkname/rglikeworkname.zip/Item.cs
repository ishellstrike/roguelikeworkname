﻿namespace dungeondata.Dungeon.Item
{
    public class Item
    {
        public int id;
        public int count;
    }
}