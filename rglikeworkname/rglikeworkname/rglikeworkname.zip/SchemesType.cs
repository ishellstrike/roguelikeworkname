namespace dungeondata.Dungeon.Level {
    public enum SchemesType
    {
        house,
        shop,
        hospital
    }
}