﻿namespace dungeondata.Dungeon.Level
{
    public class Floor
    {
        public int ID;
    }
}