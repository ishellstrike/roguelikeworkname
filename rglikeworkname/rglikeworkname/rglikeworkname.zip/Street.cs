﻿using Microsoft.Xna.Framework;

namespace dungeondata.Dungeon.Level
{
    public class Street
    {
        public Vector2 from, to;
        public float widthdiv2;
        public bool trot;
        public float trotwidth;
        public int id;
        public int tid;
    }
}