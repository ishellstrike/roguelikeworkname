using System.Collections.Generic;

namespace dungeondata.Dungeon.Level {
    public class StorageBlock : Block
    {
        public List<Item.Item> storedItems;
    }
}