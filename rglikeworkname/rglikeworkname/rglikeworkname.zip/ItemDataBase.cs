using System.Collections.Generic;
using System.Collections.ObjectModel;
using Microsoft.Xna.Framework.Graphics;

namespace dungeondata.Dungeon.Item {
    public class ItemDataBase
    {
        public Dictionary<int, ItemData> data;
        public Collection<Texture2D> texatlas;

        public ItemDataBase(Collection<Texture2D> texatlas_) {
            texatlas = texatlas_;
            data = new Dictionary<int, ItemData>();
            data.Add(0, new ItemData{name = "blank item", stackNo = 20, mtex = 0});
            data.Add(1, new ItemData { name = "����� � ��������!!!", stackNo = 20 , mtex = 3});
            data.Add(2, new ItemData {
                                         name = "����� � �������� 2!!!",
                                         stackNo = 20,
                                         mtex = 2
                                     });
        }
    }
}