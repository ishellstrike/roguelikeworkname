namespace dungeondata.Dungeon.Level {
    public enum SmartAction 
    {
        ActionSee,
        ActionLoot,
        ActionSmash,
        ActionOpenContainer,
        ActionHide
    }
}