namespace dungeondata.Dungeon.Item {
    internal enum ItemType
    {
        Nothing,

        Hat,
        Glaces,
        Helmet,

        Chest,
        Shirt,

        Pants,

        Gloves,

        Boots,

        Ammo,

        Food,
        Medicine,

        Parts,

        Currency
    }
}