﻿namespace dungeondata.Dungeon.Level
{
    public class Schemes
    {
        public int x, y;
        public int[] data;
        public SchemesType type;
    }
}
